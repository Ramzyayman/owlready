local level = 0

function floodSA(source,command,speed)
	if (isObjectInACLGroup ("user."..getAccountName(getPlayerAccount(source)),aclGetGroup("Admin"))) then
		if (speed) then
			if (isTimer(waterTimer)) then
				killTimer(waterTimer)
				destroyElement(floodWater)
				setWaterLevel(0)
				level = 0
				outputDebugString ("Previous flooding has been stopped by the server.")
			end
			local speed = tonumber(speed)
			floodWater = createWater(-2998,-2998,0,2998,-2998,0,-2998,2998,0,2998,2998,0)
			outputChatBox("--------------------------------",getRootElement(),255,0,0)
			outputChatBox("ALERT: A FLOOD IS EMERGING! FIND HIGH GROUND!!!",getRootElement(),255,0,0)
			outputChatBox("--------------------------------",getRootElement(),255,0,0)
			waterTimer = setTimer(addSomeWater,100,0,speed)
			outputDebugString("Flooding started by "..getPlayerName (source).." at a speed of "..speed..".")
		else
			outputChatBox("You must specify a speed.",source,255,0,0)
		end
	else
		outputChatBox ("You must be an admin to use this command!",source,255,0,0)
	end
end
addCommandHandler("flood",floodSA)

function addSomeWater(speed)
    level = level+speed/100
    setWaterLevel(level)
end

function stopFlood(source,command)
	if (isObjectInACLGroup("user."..getAccountName(getPlayerAccount(source)),aclGetGroup("Admin"))) then
			if (isTimer(waterTimer)) then
				killTimer(waterTimer)
				destroyElement(floodWater)
				setWaterLevel(0)
				level = 0
				outputDebugString("Flooding stopped by "..getPlayerName(source)..".")
				outputChatBox("THE FLOOD HAS PASSED, RETURN TO YOUR HOMES!",getRootElement(),255,0,0)
			else
				outputChatBox("There is no flood to stop.",source,255,0,0)
			end
	else
		outputChatBox ("You must be an admin to use this command!",source,255,0,0)
	end
end
addCommandHandler("flood-stop",stopFlood)

function resetWater()
	setWaterLevel(0)
end
addEventHandler("onResourceStop",getResourceRootElement(getThisResource()),resetWater)